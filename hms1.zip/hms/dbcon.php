<?php

$con=mysqli_connect('localhost','root','','hms');

if ($con==false) {

	echo "connetion not ok";
}

?>