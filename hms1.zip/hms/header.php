<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>WELCOME TO ACSCE HOSTEL</title>
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<link href="css/styl.css" rel="stylesheet" type="text/css">
	<link href="css/slide.css" rel="stylesheet" type="text/css">
	<style>
.mySlides {display:none;}
.footer {
    position: fixed;
    margin-left: 40px;
    bottom: 0;
    width: 93%;
    background-color: red;
    color: white;
    text-align: center;
    }
</style>
</head>
<body>

